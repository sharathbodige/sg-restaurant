package com.sgrestaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgRestaurantApplication {
    public static void main(String[] args) {
        SpringApplication.run(SgRestaurantApplication.class, args);
    }
}